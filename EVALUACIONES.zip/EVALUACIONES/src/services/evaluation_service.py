from ..models.examen_escrito import ExamenEscrito
from ..models.practica_calificada import PracticaCalificada
from ..models.proyecto_grupal import ProyectoGrupal
from ..models.exposicion import Exposicion
from ..storage.json_storage import JSONStorage

CLASS_MAP = {
    "ExamenEscrito": ExamenEscrito,
    "PracticaCalificada": PracticaCalificada,
    "ProyectoGrupal": ProyectoGrupal,
    "Exposicion": Exposicion,
}

class EvaluationService:
    def __init__(self, storage=None):
        self.storage = storage or JSONStorage()
        self.evaluaciones = []
        self._load()

    def _load(self):
        raw = self.storage.load_all()
        for item in raw:
            cls = CLASS_MAP.get(item.get("tipo"))
            if cls:
                try:
                    ev = cls.from_dict(item)
                    self.evaluaciones.append(ev)
                except Exception as e:
                    print("Error cargando evaluación:", e)

    def _save(self):
        data = [e.to_dict() for e in self.evaluaciones]
        return self.storage.save_all(data)

    def add_evaluacion(self, evaluacion):
        self.evaluaciones.append(evaluacion)
        return self._save()

    def list_evaluaciones(self):
        return list(self.evaluaciones)

    def get_by_codigo(self, codigo):
        for e in self.evaluaciones:
            if e.codigo_eval == codigo:
                return e
        return None

    def remove_evaluacion(self, codigo):
        e = self.get_by_codigo(codigo)
        if e:
            self.evaluaciones.remove(e)
            return self._save()
        return False

    def agregar_nota(self, codigo, estudiante, nota):
        e = self.get_by_codigo(codigo)
        if not e:
            raise KeyError("Evaluación no encontrada")
        e.agregar_calificacion(estudiante, nota)
        return self._save()

    def generar_estadisticas(self, codigo):
        e = self.get_by_codigo(codigo)
        if not e:
            raise KeyError("Evaluación no encontrada")
        return e.generar_estadisticas()