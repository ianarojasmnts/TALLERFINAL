import json
import os

class JSONStorage:
    def __init__(self, filepath="data/evaluations.json"):
        self.filepath = filepath
        self._ensure_path()

    def _ensure_path(self):
        directory = os.path.dirname(self.filepath)
        if not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)

    def load_all(self):
        if not os.path.exists(self.filepath):
            return []
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return []

    def save_all(self, data):
        self._ensure_path()
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            return True
        except:
            return False