from abc import ABC, abstractmethod
from typing import Dict, Any
import statistics

class Evaluacion(ABC):
    """Clase abstracta base para cualquier evaluación."""
    def __init__(self, codigo_eval: str, curso: str, fecha: str, peso_porcentaje: float):
        self.__codigo_eval = codigo_eval
        self.__curso = curso
        self.__fecha = fecha
        self.__peso_porcentaje = float(peso_porcentaje)
        self._calificaciones = {}

    # propiedades
    @property
    def codigo_eval(self):
        return self.__codigo_eval

    @property
    def curso(self):
        return self.__curso

    @property
    def fecha(self):
        return self.__fecha

    @property
    def peso_porcentaje(self):
        return self.__peso_porcentaje

    # manejo de calificaciones
    def agregar_calificacion(self, estudiante, nota):
        if not (0 <= nota <= 20):
            raise ValueError("La nota debe estar entre 0 y 20")
        self._calificaciones[estudiante] = float(nota)

    def eliminar_calificacion(self, estudiante):
        self._calificaciones.pop(estudiante, None)

    def obtener_calificaciones(self):
        return dict(self._calificaciones)

    # método privado
    def __aplicar_curva(self, nota):
        return min(nota * 1.05, 20.0)

    def obtener_nota_final(self, estudiante):
        if estudiante not in self._calificaciones:
            raise KeyError("Estudiante no encontrado")
        return self.__aplicar_curva(self._calificaciones[estudiante])

    # serialización
    def to_dict(self):
        return {
            "tipo": self.__class__.__name__,
            "codigo_eval": self.codigo_eval,
            "curso": self.curso,
            "fecha": self.fecha,
            "peso_porcentaje": self.peso_porcentaje,
            "calificaciones": self.obtener_calificaciones(),
        }

    @classmethod
    @abstractmethod
    def from_dict(cls, data):
        pass

    @abstractmethod
    def calcular_nota_estudiante(self, estudiante):
        pass

    @abstractmethod
    def generar_estadisticas(self):
        pass