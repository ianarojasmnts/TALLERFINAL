from .evaluacion import Evaluacion
import statistics

class ProyectoGrupal(Evaluacion):
    def __init__(self, codigo_eval, curso, fecha, peso_porcentaje,
                 num_integrantes, etapas, peso_por_etapa):
        super().__init__(codigo_eval, curso, fecha, peso_porcentaje)
        self.num_integrantes = num_integrantes
        self.etapas = etapas
        self.peso_por_etapa = peso_por_etapa

    def calcular_nota_estudiante(self, estudiante):
        nota = self.obtener_nota_final(estudiante)
        factor = 1 - max(0, self.num_integrantes - 4) * 0.01
        return max(min(nota * factor, 20), 0)

    def generar_estadisticas(self):
        notas = [self.calcular_nota_estudiante(e) for e in self.obtener_calificaciones()]
        if not notas:
            return {"total": 0}
        return {
            "total": len(notas),
            "promedio": statistics.mean(notas),
            "mediana": statistics.median(notas),
            "aprobados": sum(n >= 10 for n in notas),
            "desaprobados": sum(n < 10 for n in notas),
        }

    @classmethod
    def from_dict(cls, data):
        obj = cls(
            data["codigo_eval"], data["curso"], data["fecha"], data["peso_porcentaje"],
            data.get("num_integrantes", 1), data.get("etapas", 1),
            data.get("peso_por_etapa", 1)
        )
        for est, nota in data.get("calificaciones", {}).items():
            obj._calificaciones[est] = nota
        return obj