from .evaluacion import Evaluacion
import statistics

class ProyectoGrupal(Evaluacion):
 

    def __init__(self, codigo_eval, curso, fecha, peso_porcentaje,
                 num_integrantes, etapas, peso_por_etapa):
      

        super().__init__(codigo_eval, curso, fecha, peso_porcentaje)

        self.num_integrantes = int(num_integrantes)
        self.etapas = etapas                      # Lista de etapas
        self.peso_por_etapa = peso_por_etapa      # Lista de pesos por etapa

        if len(etapas) != len(peso_por_etapa):
            raise ValueError("Las etapas y pesos deben tener la misma longitud")

        if sum(peso_por_etapa) != 100:
            raise ValueError("La suma de los pesos de las etapas debe ser 100")

       
        self._calificaciones = {}

    def agregar_calificacion_etapa(self, estudiante, etapa, nota):
        if etapa not in self.etapas:
            raise ValueError(f"Etapa '{etapa}' no existe en este proyecto.")

        if not (0 <= nota <= 20):
            raise ValueError("La nota debe estar entre 0 y 20.")

        if estudiante not in self._calificaciones:
            self._calificaciones[estudiante] = {}

        self._calificaciones[estudiante][etapa] = nota

    
    def calcular_nota_estudiante(self, estudiante):
        """
        Calcula la nota final del estudiante como suma ponderada
        de las etapas del proyecto.
        """
        if estudiante not in self._calificaciones:
            raise KeyError("El estudiante no tiene calificaciones registradas.")

        notas = self._calificaciones[estudiante]

        nota_final = 0
        for etapa, peso in zip(self.etapas, self.peso_por_etapa):
            nota_etapa = notas.get(etapa, 0)  # Si falta una etapa, vale 0
            nota_final += nota_etapa * (peso / 100)

       
        return super().obtener_nota_final_estandar(nota_final)

   
    def generar_estadisticas(self):
        """
        Devuelve: promedio, mediana, aprobados y desaprobados.
        """
        notas_finales = [self.calcular_nota_estudiante(est)
                         for est in self._calificaciones]

        if not notas_finales:
            return {
                "promedio": 0,
                "mediana": 0,
                "aprobados": 0,
                "desaprobados": 0
            }

        return {
            "promedio": round(statistics.mean(notas_finales), 2),
            "mediana": round(statistics.median(notas_finales), 2),
            "aprobados": sum(1 for n in notas_finales if n >= 11),
            "desaprobados": sum(1 for n in notas_finales if n < 11)
        }


    def to_dict(self):
        base = super().to_dict()
        base.update({
            "num_integrantes": self.num_integrantes,
            "etapas": self.etapas,
            "peso_por_etapa": self.peso_por_etapa,
            "calificaciones": self._calificaciones
        })
        return base

    @classmethod
    def from_dict(cls, data):
        obj = cls(
            data["codigo_eval"],
            data["curso"],
            data["fecha"],
            data["peso_porcentaje"],
            data["num_integrantes"],
            data["etapas"],
            data["peso_por_etapa"]
        )
        obj._calificaciones = data["calificaciones"]
        return obj

    def obtener_calificaciones(self):
        """ Retorna las notas por estudiante y etapa. """
        return self._calificaciones