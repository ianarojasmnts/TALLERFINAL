from .evaluacion import Evaluacion
import statistics

class PracticaCalificada(Evaluacion):
    def __init__(self, codigo_eval, curso, fecha, peso_porcentaje,
                 ejercicios, tiempo_minutos, puede_consultar_material):
        super().__init__(codigo_eval, curso, fecha, peso_porcentaje)
        self.ejercicios = ejercicios
        self.tiempo_minutos = tiempo_minutos
        self.puede_consultar_material = puede_consultar_material

    def calcular_nota_estudiante(self, estudiante):
        nota = self.obtener_nota_final(estudiante)
        return max(nota * (0.98 if self.puede_consultar_material else 1), 0)

    def generar_estadisticas(self):
        notas = [self.calcular_nota_estudiante(e) for e in self.obtener_calificaciones()]
        if not notas:
            return {"total": 0}
        return {
            "total": len(notas),
            "promedio": statistics.mean(notas),
            "mediana": statistics.median(notas),
            "aprobados": sum(n >= 10 for n in notas),
            "desaprobados": sum(n < 10 for n in notas),
        }

    @classmethod
    def from_dict(cls, data):
        obj = cls(
            data["codigo_eval"], data["curso"], data["fecha"], data["peso_porcentaje"],
            data.get("ejercicios", 0), data.get("tiempo_minutos", 0),
            data.get("puede_consultar_material", False)
        )
        for est, nota in data.get("calificaciones", {}).items():
            obj._calificaciones[est] = nota
        return obj