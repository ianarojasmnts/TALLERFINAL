from ..services.evaluation_service import EvaluationService
from ..models.examen_escrito import ExamenEscrito
from ..models.practica_calificada import PracticaCalificada
from ..models.proyecto_grupal import ProyectoGrupal
from ..models.exposicion import Exposicion

class MenuUI:
    def __init__(self):
        self.service = EvaluationService()

    def show_main(self):
        print("\n=== SISTEMA DE EVALUACIONES ===\n")
        print("1. Crear evaluación")
        print("2. Listar evaluaciones")
        print("3. Agregar calificación")
        print("4. Ver estadísticas")
        print("5. Eliminar evaluación")
        print("0. Salir\n")

    def run(self):
        while True:
            self.show_main()
            op = input("Selecciona una opción: ")

            if op == "0":
                print("Saliendo…")
                break
            elif op == "1":
                self._crear_evaluacion()
            elif op == "2":
                self._listar()
            elif op == "3":
                self._agregar_calificacion()
            elif op == "4":
                self._estadisticas()
            elif op == "5":
                self._eliminar()
            else:
                print("Opción inválida")

    def _crear_evaluacion(self):
        print("\n--- Crear evaluación ---")
        print("1) ExamenEscrito")
        print("2) PracticaCalificada")
        print("3) ProyectoGrupal")
        print("4) Exposicion")

        tipo = input("Tipo: ")
        codigo = input("Código: ")
        curso = input("Curso: ")
        fecha = input("Fecha (YYYY-MM-DD): ")
        peso = float(input("Peso %: "))

        if tipo == "1":
            ev = ExamenEscrito(
                codigo, curso, fecha, peso,
                int(input("Num preguntas: ")),
                int(input("Tiempo (min): ")),
                input("Tipo (multiple/desarrollo): ")
            )

        elif tipo == "2":
            ev = PracticaCalificada(
                codigo, curso, fecha, peso,
                int(input("Ejercicios: ")),
                int(input("Tiempo (min): ")),
                input("Puede consultar material (s/n): ").lower() == "s"
            )

        elif tipo == "3":
            ev = ProyectoGrupal(
                codigo, curso, fecha, peso,
                int(input("Integrantes: ")),
                int(input("Etapas: ")),
                float(input("Peso por etapa: "))
            )

        elif tipo == "4":
            ev = Exposicion(
                codigo, curso, fecha, peso,
                int(input("Duración (min): ")),
                input("Rúbrica: "),
                int(input("Preguntas respondidas: "))
            )

        else:
            print("Tipo inválido")
            return

        if self.service.add_evaluacion(ev):
            print("Evaluación creada.")
        else:
            print("Error guardando evaluación.")

    def _listar(self):
        print("\n--- Lista de evaluaciones ---")
        for e in self.service.list_evaluaciones():
            print(f"{e.codigo_eval} | {e.__class__.__name__} | {e.curso}")

    def _agregar_calificacion(self):
        codigo = input("Código eval: ")
        estudiante = input("Estudiante: ")
        nota = float(input("Nota (0-20): "))
        try:
            self.service.agregar_nota(codigo, estudiante, nota)
            print("Calificación agregada.")
        except Exception as e:
            print("Error:", e)

    def _estadisticas(self):
        codigo = input("Código eval: ")
        try:
            stats = self.service.generar_estadisticas(codigo)
            print(stats)
        except Exception as e:
            print("Error:", e)

    def _eliminar(self):
        codigo = input("Código eval: ")
        if self.service.remove_evaluacion(codigo):
            print("Eliminada")
        else:
            print("No encontrada")