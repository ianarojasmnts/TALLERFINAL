from src.ui.menu import MenuUI

def main():
    ui = MenuUI()
    ui.run()

if __name__ == '__main__':
    main()